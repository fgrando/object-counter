This is Carotene, a low-level library containing optimized CPU routines
that are useful for computer vision algorithms.
